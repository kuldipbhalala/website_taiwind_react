

const baseUrl="https://fakestoreapi.com/products"

export default baseUrl