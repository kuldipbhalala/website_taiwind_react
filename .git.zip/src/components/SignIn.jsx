import React from 'react'
import { useNavigate } from 'react-router-dom'

function SignIn() {
    const navigate = useNavigate();

    return (
        <div>
            <div className=" grid grid-cols-1 md:grid-cols-2">
                <div className="relative">
                    <img src="/assets/Img/chair.png" alt className="w-[100%] h-[100vh] md:w-[85%] md:h-[100vh]" />
                    <h2 className="absolute top-[5%]  text-2xl font-semibold left-[35%]">3legant.</h2>
                </div>
                <div className="container py-5 px-5 md:pl-[50px] md:pt-[8.75rem]">
                    <div>
                        <h2 className="text-3xl font-semibold py-4">Sign In</h2>
                        <p className="text-[#6C7275] ">Don’t have an accout yet? <span className="text-[#38CB89] font-semibold">Sign
                            Up</span> </p>
                    </div>
                    <div className="py-4">
                        <p className="text-[#6C7275]">Your usernam or email address</p>
                        <input type="text" id="username" name="username" className="w-[100%] focus:border-none focus:outline-none" />
                        <div className="border-[1px] cursor-pointer border-[#E8ECEF]] w-[99%] md:w-[50%]" />
                    </div>
                    <div className="py-4">
                        <p className="text-[#6C7275]">Password</p>
                        <input type="password" id="username" name="username" className="w-[100%] focus:border-none focus:outline-none" />
                        <div className="border-[1px] cursor-pointer  border-[#E8ECEF]] w-[99%] md:w-[50%]" />
                    </div>
                    <div className="py-4 flex items-center">
                        <input type="checkbox" id="checkbox" name="checkbox" className="w-4 h-5" />
                        <p className="text-[12px] text-[#6C7275] px-2 pe-7 xl:pe-28">Remember me</p>
                        <p><a href>Forgot password?</a></p>
                    </div>
                    <button onClick={() => navigate("/Signup")} className="py-2   px-[40%] md:px-[32%] lg:px-[22%] rounded-md bg-black text-white">Sign up</button>
                </div>
            </div>
        </div>

    )
}

export default SignIn